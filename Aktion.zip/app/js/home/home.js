import Swiper, { Navigation } from 'swiper';
import { debounce } from 'debounce';

export default class Home {
    constructor(root) {
        this.initSlider('.technologies');
        this.initSlider('.cooperation');
        const directionsBlock = root.getElementsByClassName('directions')[0];
        this.directionsToggler(directionsBlock);

        const obj = document.getElementsByClassName('results')[0];
        obj.onload = function() {
        	const objDoc = obj.contentDocument;
        	const svg = objDoc.getElementsByTagName('svg')[0];
        	svg.removeAttribute('width');
            svg.removeAttribute('height');
            svg.setAttribute('preserveAspectRatio', 'none');
            // svg.setAttribute('viewBox', '0 0 100 100');
        }
    }

    initSlider(className) {
        Swiper.use([Navigation]);

        const slider = new Swiper(className, {
            slidesPerView: 3,
            navigation: {
                nextEl: className + '__next',
                prevEl: className + '__prev',
            },
            breakpoints: {
                320: {
                    slidesPerView: 'auto',
                    spaceBetween: 17,
                },
                790: {
                    slidesPerView: 3,
                    spaceBetween: 24,
                }
            }
        });
    }

    directionsToggler(directionsBlock) {
        const directionsList = directionsBlock.getElementsByClassName('directions__item');
        window.onresize = debounce(resize, 300);
        
        function resize() {
            if (window.innerWidth < 790) {
                if (directionsList && directionsList.length) {
                    const height = directionsList[7].offsetTop;

                    console.log('height', height)
                }
            }
        }
    }
}